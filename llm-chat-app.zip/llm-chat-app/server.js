// server.js
// Servidor local. Lê as chaves do .env e nunca as expõe ao navegador.
// O frontend só conhece IDs de modelo/provedor; toda chamada de API
// real acontece aqui, no servidor, usando a chave correspondente.

require("dotenv").config();
const express = require("express");
const fetch = require("node-fetch");
const path = require("path");
const { CATALOG } = require("./catalog");

const app = express();
const PORT = process.env.PORT || 3344;

app.use(express.json({ limit: "5mb" }));
app.use(express.static(path.join(__dirname, "public")));

// -----------------------------------------------------------------
// GET /api/catalog
// Devolve o catálogo de provedores/modelos + se cada provedor tem
// uma chave configurada no .env (true/false — nunca a chave em si).
// -----------------------------------------------------------------
app.get("/api/catalog", (req, res) => {
  const out = {};
  for (const [providerId, provider] of Object.entries(CATALOG)) {
    const hasKey = Boolean(process.env[provider.envKey] && process.env[provider.envKey].trim());
    out[providerId] = {
      label: provider.label,
      color: provider.color,
      docsUrl: provider.docsUrl,
      hasKey,
      knownIssue: provider.knownIssue || null,
      models: provider.models
    };
  }
  res.json(out);
});

// -----------------------------------------------------------------
// Helpers de chamada por provedor.
// Cada um recebe (modelId, messages) e devolve { text } ou lança erro.
// -----------------------------------------------------------------

async function callAnthropic(modelId, messages, systemPrompt) {
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) throw new Error("ANTHROPIC_API_KEY não configurada no .env");

  const resp = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": key,
      "anthropic-version": "2023-06-01"
    },
    body: JSON.stringify({
      model: modelId,
      max_tokens: 1024,
      system: systemPrompt || undefined,
      messages: messages.map(m => ({ role: m.role, content: m.content }))
    })
  });

  if (!resp.ok) {
    const errText = await resp.text();
    throw new Error(`Anthropic ${resp.status}: ${errText}`);
  }
  const data = await resp.json();
  const text = (data.content || []).map(b => b.text || "").join("");
  return { text, raw: data };
}

async function callOpenAICompatible(baseUrl, apiKey, modelId, messages, systemPrompt, extraHeaders = {}) {
  if (!apiKey) throw new Error(`Chave de API não configurada para ${baseUrl}`);

  const fullMessages = systemPrompt
    ? [{ role: "system", content: systemPrompt }, ...messages]
    : messages;

  const resp = await fetch(`${baseUrl}/chat/completions`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
      ...extraHeaders
    },
    body: JSON.stringify({
      model: modelId,
      messages: fullMessages,
      max_tokens: 1024
    })
  });

  if (!resp.ok) {
    const errText = await resp.text();
    throw new Error(`${baseUrl} ${resp.status}: ${errText}`);
  }
  const data = await resp.json();
  const text = data.choices?.[0]?.message?.content || "";
  return { text, raw: data };
}

async function callGemini(modelId, messages, systemPrompt) {
  const key = process.env.GEMINI_API_KEY;
  if (!key) throw new Error("GEMINI_API_KEY não configurada no .env");

  const contents = messages.map(m => ({
    role: m.role === "assistant" ? "model" : "user",
    parts: [{ text: m.content }]
  }));

  const body = {
    contents,
    ...(systemPrompt ? { systemInstruction: { parts: [{ text: systemPrompt }] } } : {})
  };

  const resp = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${modelId}:generateContent?key=${key}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    }
  );

  if (!resp.ok) {
    const errText = await resp.text();
    throw new Error(`Gemini ${resp.status}: ${errText}`);
  }
  const data = await resp.json();
  const text = data.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("") || "";
  return { text, raw: data };
}

// Roteador central: decide qual provedor chamar.
async function callProvider(providerId, modelId, messages, systemPrompt) {
  switch (providerId) {
    case "anthropic":
      return callAnthropic(modelId, messages, systemPrompt);

    case "openai":
      return callOpenAICompatible(
        "https://api.openai.com/v1",
        process.env.OPENAI_API_KEY,
        modelId,
        messages,
        systemPrompt
      );

    case "gemini":
      return callGemini(modelId, messages, systemPrompt);

    case "groq":
      return callOpenAICompatible(
        "https://api.groq.com/openai/v1",
        process.env.GROQ_API_KEY,
        modelId,
        messages,
        systemPrompt
      );

    case "cerebras":
      return callOpenAICompatible(
        "https://api.cerebras.ai/v1",
        process.env.CEREBRAS_API_KEY,
        modelId,
        messages,
        systemPrompt
      );

    case "mistral":
      return callOpenAICompatible(
        "https://api.mistral.ai/v1",
        process.env.MISTRAL_API_KEY,
        modelId,
        messages,
        systemPrompt
      );

    case "nvidia":
      return callOpenAICompatible(
        "https://integrate.api.nvidia.com/v1",
        process.env.NVIDIA_API_KEY,
        modelId,
        messages,
        systemPrompt
      );

    case "openrouter":
      return callOpenAICompatible(
        "https://openrouter.ai/api/v1",
        process.env.OPENROUTER_API_KEY,
        modelId,
        messages,
        systemPrompt,
        {
          "HTTP-Referer": "http://localhost",
          "X-Title": "Console LLM Local"
        }
      );

    default:
      throw new Error(`Provedor desconhecido: ${providerId}`);
  }
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// Erros transitórios (sobrecarga momentânea, rate limit) valem uma
// segunda tentativa rápida antes de cair pro próximo elo da cadeia.
// Erros definitivos (chave ausente/inválida, modelo descontinuado,
// 4xx que não seja 429) não merecem retry — só atrasariam o fallback.
function isTransientError(message) {
  return /\b(429|503)\b/.test(message) || /UNAVAILABLE|rate.?limit/i.test(message);
}

async function callProviderWithRetry(providerId, modelId, messages, systemPrompt) {
  const maxAttempts = 2;
  let lastErr;
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      return await callProvider(providerId, modelId, messages, systemPrompt);
    } catch (err) {
      lastErr = err;
      const message = String(err.message || err);
      if (attempt < maxAttempts && isTransientError(message)) {
        await sleep(700 * attempt); // 700ms, depois 1400ms
        continue;
      }
      throw err;
    }
  }
  throw lastErr;
}

// -----------------------------------------------------------------
// POST /api/chat
// body: { messages, systemPrompt, chain: [{provider, modelId}, ...] }
// Tenta o primeiro item da cadeia (com 1 retry se o erro for transitório);
// se ainda falhar, tenta o próximo. Devolve qual elo respondeu de fato.
// -----------------------------------------------------------------
app.post("/api/chat", async (req, res) => {
  const { messages, systemPrompt, chain } = req.body;

  if (!Array.isArray(chain) || chain.length === 0) {
    return res.status(400).json({ error: "Cadeia de modelos (chain) vazia ou ausente." });
  }

  const attempts = [];

  for (let i = 0; i < chain.length; i++) {
    const { provider, modelId } = chain[i];
    try {
      const result = await callProviderWithRetry(provider, modelId, messages, systemPrompt);
      return res.json({
        ok: true,
        text: result.text,
        usedProvider: provider,
        usedModelId: modelId,
        usedFallbackLevel: i, // 0 = principal, 1 = fallback 1, 2 = fallback 2
        attempts
      });
    } catch (err) {
      attempts.push({ provider, modelId, error: String(err.message || err) });
      // segue para o próximo da cadeia
    }
  }

  return res.status(502).json({
    ok: false,
    error: "Todos os modelos da cadeia falharam.",
    attempts
  });
});

app.listen(PORT, () => {
  console.log(`\n  Console LLM rodando em http://localhost:${PORT}\n`);
});
