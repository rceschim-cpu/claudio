// app.js
// Lógica do frontend: nenhuma chave de API passa por aqui.
// Este arquivo só conhece IDs de provedor/modelo; toda chamada real
// é feita pelo servidor local em /api/chat.

let CATALOG = {};
let activeProvider = null;
let chain = [null, null, null]; // {provider, modelId, name, input, output, color}

const providerRail = document.getElementById("provider-rail");
const modelPanel = document.getElementById("model-panel");
const btnStart = document.getElementById("btn-start-chat");
const btnClear = document.getElementById("btn-clear-chain");

init();

async function init() {
  const res = await fetch("/api/catalog");
  CATALOG = await res.json();
  renderProviderRail();
  // seleciona o primeiro provedor com chave configurada, senão o primeiro da lista
  const firstWithKey = Object.keys(CATALOG).find(p => CATALOG[p].hasKey);
  selectProvider(firstWithKey || Object.keys(CATALOG)[0]);
  renderChainPanel();
}

// -----------------------------------------------------------------
// Coluna de provedores
// -----------------------------------------------------------------
function renderProviderRail() {
  providerRail.innerHTML = "";
  for (const [providerId, provider] of Object.entries(CATALOG)) {
    const btn = document.createElement("button");
    btn.className = "provider-btn" + (providerId === activeProvider ? " active" : "");
    btn.innerHTML = `
      <span class="provider-swatch" style="background:${provider.color}"></span>
      <span>${provider.label}</span>
      <span class="provider-key-flag ${provider.hasKey ? "flag-ok" : "flag-missing"}">
        ${provider.hasKey ? "OK" : "SEM KEY"}
      </span>
    `;
    btn.addEventListener("click", () => selectProvider(providerId));
    providerRail.appendChild(btn);
  }
}

function selectProvider(providerId) {
  activeProvider = providerId;
  renderProviderRail();
  renderModelPanel();
}

// -----------------------------------------------------------------
// Coluna de modelos do provedor ativo
// -----------------------------------------------------------------
function renderModelPanel() {
  const provider = CATALOG[activeProvider];
  if (!provider) return;

  let html = `
    <div class="model-panel-header">
      <h2>${provider.label}</h2>
      <a class="model-panel-link" href="${provider.docsUrl}" target="_blank" rel="noopener">obter chave →</a>
    </div>
  `;

  if (!provider.hasKey) {
    html += `
      <div class="model-panel-warning">
        ⚠ Nenhuma chave encontrada para este provedor no arquivo .env.
        Você ainda pode montar a cadeia, mas a chamada vai falhar até você adicionar a chave e reiniciar o servidor.
      </div>
    `;
  }

  if (provider.knownIssue) {
    html += `
      <div class="model-panel-warning model-panel-warning-issue">
        🛈 Problema conhecido neste provedor: ${provider.knownIssue}
      </div>
    `;
  }

  html += `<div class="model-grid">`;

  for (const model of provider.models) {
    const isFree = model.input === 0 && model.output === 0;
    const tierClass = isFree ? "tier-free" : "";
    const priceClass = isFree ? "price-free" : "";

    html += `
      <article class="model-card">
        <div class="model-card-name">${model.name}</div>
        <div class="model-card-tier ${tierClass}">${model.tier}</div>
        <div class="model-card-notes">${model.notes}</div>
        <div class="model-card-meta">
          <div class="meta-item">
            <span class="meta-label">Entrada /1M tok</span>
            <span class="meta-value ${priceClass}">${isFree ? "grátis" : "$" + model.input.toFixed(2)}</span>
          </div>
          <div class="meta-item">
            <span class="meta-label">Saída /1M tok</span>
            <span class="meta-value ${priceClass}">${isFree ? "grátis" : "$" + model.output.toFixed(2)}</span>
          </div>
          <div class="meta-item">
            <span class="meta-label">Contexto</span>
            <span class="meta-value">${model.context}</span>
          </div>
          <div class="meta-item" style="flex:1 1 100%">
            <span class="meta-label">Outputs suportados</span>
            <span class="meta-value">${model.outputs.join(" · ")}</span>
          </div>
        </div>
        <div class="model-card-actions">
          ${[0, 1, 2].map(slotIdx => `
            <button
              class="btn-assign"
              data-provider="${activeProvider}"
              data-model-id="${model.id}"
              data-slot="${slotIdx}"
            >→ slot ${slotIdx + 1}</button>
          `).join("")}
        </div>
      </article>
    `;
  }

  html += `</div>`;
  modelPanel.innerHTML = html;

  modelPanel.querySelectorAll(".btn-assign").forEach(btn => {
    btn.addEventListener("click", () => {
      const slot = Number(btn.dataset.slot);
      const modelId = btn.dataset.modelId;
      const providerId = btn.dataset.provider;
      assignSlot(slot, providerId, modelId);
    });
  });
}

// -----------------------------------------------------------------
// Cadeia (principal / fallback1 / fallback2)
// -----------------------------------------------------------------
function findModel(providerId, modelId) {
  return CATALOG[providerId].models.find(m => m.id === modelId);
}

function assignSlot(slotIdx, providerId, modelId) {
  const model = findModel(providerId, modelId);
  chain[slotIdx] = {
    provider: providerId,
    modelId,
    name: model.name,
    input: model.input,
    output: model.output,
    color: CATALOG[providerId].color,
    providerLabel: CATALOG[providerId].label
  };
  renderChainPanel();
}

function removeSlot(slotIdx) {
  chain[slotIdx] = null;
  renderChainPanel();
}

function renderChainPanel() {
  for (let i = 0; i < 3; i++) {
    const slotEl = document.querySelector(`.chain-slot[data-slot="${i}"]`);
    const bodyEl = document.getElementById(`slot-${i}-body`);
    const filled = chain[i];

    slotEl.classList.toggle("filled", Boolean(filled));

    if (!filled) {
      bodyEl.innerHTML = `<span class="slot-empty">— vazio —</span>`;
      continue;
    }

    const isFree = filled.input === 0 && filled.output === 0;
    bodyEl.innerHTML = `
      <div class="slot-filled-name" style="color:${filled.color}">${filled.name}</div>
      <div class="slot-filled-provider">${filled.providerLabel}</div>
      <div class="slot-filled-price">${isFree ? "grátis" : "$" + filled.input.toFixed(2) + " / $" + filled.output.toFixed(2) + " por 1M tok"}</div>
      <button class="slot-remove" data-remove-slot="${i}">remover</button>
    `;
  }

  document.querySelectorAll("[data-remove-slot]").forEach(btn => {
    btn.addEventListener("click", () => removeSlot(Number(btn.dataset.removeSlot)));
  });

  // Habilita "iniciar conversa" só se o slot principal (0) estiver preenchido
  btnStart.disabled = !chain[0];
}

btnClear.addEventListener("click", () => {
  chain = [null, null, null];
  renderChainPanel();
});

document.getElementById("btn-start-chat").addEventListener("click", () => {
  goToChatScreen();
});

document.getElementById("btn-back").addEventListener("click", () => {
  document.getElementById("screen-chat").classList.add("screen-hidden");
  document.getElementById("screen-setup").classList.remove("screen-hidden");
});

// -----------------------------------------------------------------
// Tela 2 — chat
// -----------------------------------------------------------------
let conversation = []; // { role: "user"|"assistant", content: string }

function goToChatScreen() {
  document.getElementById("screen-setup").classList.add("screen-hidden");
  document.getElementById("screen-chat").classList.remove("screen-hidden");
  renderStatusChain(0, []);
  setActiveModelLabel(chain[0]);
}

function renderStatusChain(currentLevel, failedLevels) {
  const el = document.getElementById("status-chain");
  const activeChain = chain.filter(Boolean);
  el.innerHTML = activeChain.map((step, idx) => {
    let cls = "status-chain-item";
    if (failedLevels.includes(idx)) cls += " is-failed";
    else if (idx === currentLevel) cls += " is-current";

    const arrow = idx < activeChain.length - 1
      ? `<span class="status-chain-arrow">→</span>`
      : "";

    return `<span class="${cls}">${idx === 0 ? "principal" : "fallback " + idx}: ${step.name}</span>${arrow}`;
  }).join("");
}

function setActiveModelLabel(step, statusColor = "green") {
  const dot = document.getElementById("status-dot");
  const label = document.getElementById("status-active-label");
  dot.className = "dot dot-" + statusColor;
  label.textContent = step ? `${step.providerLabel} · ${step.name}` : "—";
}

const chatWindow = document.getElementById("chat-window");
const chatForm = document.getElementById("chat-form");
const chatInput = document.getElementById("chat-input");
const btnSend = document.getElementById("btn-send");

chatInput.addEventListener("input", () => {
  chatInput.style.height = "auto";
  chatInput.style.height = Math.min(chatInput.scrollHeight, 180) + "px";
});

chatInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    chatForm.requestSubmit();
  }
});

chatForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const text = chatInput.value.trim();
  if (!text) return;

  document.getElementById("chat-empty")?.remove();

  appendMessage("user", text);
  conversation.push({ role: "user", content: text });
  chatInput.value = "";
  chatInput.style.height = "auto";

  const thinkingEl = appendThinking();
  btnSend.disabled = true;

  const activeChainList = chain.filter(Boolean).map(s => ({ provider: s.provider, modelId: s.modelId }));

  try {
    const resp = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        messages: conversation,
        systemPrompt: "Você é um assistente útil, direto e honesto.",
        chain: activeChainList
      })
    });
    const data = await resp.json();
    thinkingEl.remove();

    if (!data.ok) {
      appendError("Todos os modelos da cadeia falharam:\n" + (data.attempts || []).map(a => `• ${a.provider}/${a.modelId}: ${a.error}`).join("\n"));
      renderStatusChain(0, (data.attempts || []).map((_, i) => i));
      setActiveModelLabel(null, "red");
      return;
    }

    conversation.push({ role: "assistant", content: data.text });

    const usedStep = chain.filter(Boolean)[data.usedFallbackLevel];
    const failedBefore = data.attempts.map((_, i) => i);

    appendMessage("assistant", data.text, {
      usedFallbackLevel: data.usedFallbackLevel,
      usedStep
    });

    renderStatusChain(data.usedFallbackLevel, failedBefore);
    setActiveModelLabel(usedStep, data.usedFallbackLevel === 0 ? "green" : "amber");

  } catch (err) {
    thinkingEl.remove();
    appendError("Erro de rede ao falar com o servidor local: " + err.message);
    setActiveModelLabel(null, "red");
  } finally {
    btnSend.disabled = false;
    chatInput.focus();
  }
});

function appendMessage(role, text, meta = null) {
  const div = document.createElement("div");
  div.className = "msg " + (role === "user" ? "msg-user" : "msg-assistant");
  div.textContent = text;

  if (meta && meta.usedStep) {
    const metaEl = document.createElement("div");
    const isFallback = meta.usedFallbackLevel > 0;
    metaEl.className = "msg-meta" + (isFallback ? " fallback-used" : "");
    metaEl.textContent = isFallback
      ? `⚠ respondido via fallback ${meta.usedFallbackLevel} — ${meta.usedStep.providerLabel} · ${meta.usedStep.name}`
      : `${meta.usedStep.providerLabel} · ${meta.usedStep.name}`;
    div.appendChild(metaEl);
  }

  chatWindow.appendChild(div);
  chatWindow.scrollTop = chatWindow.scrollHeight;
  return div;
}

function appendThinking() {
  const div = document.createElement("div");
  div.className = "msg-thinking";
  div.textContent = "pensando…";
  chatWindow.appendChild(div);
  chatWindow.scrollTop = chatWindow.scrollHeight;
  return div;
}

function appendError(text) {
  const div = document.createElement("div");
  div.className = "msg-error";
  div.textContent = text;
  chatWindow.appendChild(div);
  chatWindow.scrollTop = chatWindow.scrollHeight;
  return div;
}
