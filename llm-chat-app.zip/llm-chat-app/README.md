# Console LLM — chat local com múltiplos provedores

Interface web local que lê suas chaves de API de um arquivo `.env`, deixa você
escolher um modelo **principal** + até **2 fallbacks**, e conversa com eles
através de um chat que troca de modelo automaticamente se um falhar.

Suas chaves **nunca saem da sua máquina** nem são enviadas ao navegador: um
pequeno servidor local (Node/Express) lê o `.env` e faz as chamadas de API
por você. O frontend só vê nomes de modelos e respostas de texto.

## 1. Pré-requisitos

- [Node.js](https://nodejs.org) versão 18 ou superior instalado.

## 2. Instalação

```bash
cd llm-chat-app
npm install
```

## 3. Configurar suas chaves

Copie o arquivo de exemplo e cole suas chaves reais:

```bash
cp .env.example .env
```

Abra o `.env` num editor de texto e preencha **só os provedores que você
quiser usar** (não precisa preencher todos):

```env
ANTHROPIC_API_KEY=sk-ant-...
OPENAI_API_KEY=sk-...
GEMINI_API_KEY=AIza...
GROQ_API_KEY=gsk_...
NVIDIA_API_KEY=nvapi-...
OPENROUTER_API_KEY=sk-or-...
```

Onde conseguir cada chave:

| Provedor   | Onde gerar a chave                                  | Tem opção grátis?                                  |
|------------|------------------------------------------------------|------------------------------------------------------|
| Anthropic  | console.anthropic.com/settings/keys                  | Não (créditos iniciais ao criar conta)               |
| OpenAI     | platform.openai.com/api-keys                          | Não                                                   |
| Gemini     | aistudio.google.com/apikey                            | **Sim** — ~1.500 req/dia, sem cartão                  |
| Groq       | console.groq.com/keys                                  | **Sim** — até 14.400 req/dia (8B), sem cartão         |
| Cerebras   | cloud.cerebras.ai                                       | **Sim** — 1.000.000 tokens/dia, sem cartão (maior volume do catálogo) |
| Mistral AI | console.mistral.ai/api-keys                             | **Sim** — ~1B tokens/mês, exige verificação de telefone (sem cartão) |
| NVIDIA NIM | build.nvidia.com                                        | Sim, em teoria — mas muitas contas novas têm um bug de permissão conhecido (ver aviso no app) |
| OpenRouter | openrouter.ai/keys                                      | Alguns modelos `:free`, resto é pago                  |

> **Foco em gratuito:** Gemini, Groq, Cerebras e Mistral têm free tiers reais, permanentes e sem cartão de crédito — são a base mais sólida para montar uma cadeia 100% gratuita. NVIDIA também é gratuita no catálogo, mas tem o bug de permissão citado acima. OpenRouter tem alguns modelos `:free`, porém eles mudam/saem do ar com frequência.

## 4. Rodar o servidor

```bash
npm start
```

Acesse **http://localhost:3344** no navegador.

## 5. Como usar

**Tela 1 — escolha de modelos**
- Clique num provedor na coluna da esquerda.
- Veja os modelos disponíveis, com preço por 1M de tokens (entrada/saída),
  contexto e quais tipos de output cada um aceita.
- Clique em "→ slot 1/2/3" no modelo desejado para atribuí-lo como
  Principal, Fallback 1 ou Fallback 2.
- Você pode misturar provedores diferentes na mesma cadeia (ex: principal
  na Anthropic, fallback no Groq, fallback final no NVIDIA grátis).
- Quando o slot Principal estiver preenchido, o botão "Iniciar conversa"
  é liberado.

**Tela 2 — chat**
- A barra superior mostra toda a cadeia configurada e destaca qual elo
  está respondendo no momento.
- Se o modelo principal falhar (erro de API, chave inválida, limite
  excedido etc.), o sistema tenta automaticamente o Fallback 1, depois o
  Fallback 2 — e avisa visualmente quando isso acontece.
- Use "← modelos" para voltar e remontar a cadeia a qualquer momento.

## Sobre os preços mostrados

Os valores no catálogo foram levantados via pesquisa em junho/2026 e servem
como referência para comparação relativa entre modelos. Provedores ajustam
preços com frequência — confirme sempre no site oficial antes de assumir
compromissos de custo em produção. Os modelos marcados como "grátis" (NVIDIA
NIM e variantes `:free` do OpenRouter) têm limites de taxa (requisições por
minuto) em vez de cobrança por token.

## Estrutura do projeto

```
llm-chat-app/
├── server.js       # servidor Express — lê .env, faz proxy das chamadas
├── catalog.js       # catálogo de provedores/modelos/preços
├── .env.example      # modelo de variáveis de ambiente
├── package.json
└── public/
    ├── index.html    # as duas telas (setup + chat)
    ├── styles.css    # tema visual "painel de operador"
    └── app.js        # lógica do frontend (sem chaves de API)
```

## Adicionando ou ajustando modelos

Edite `catalog.js` — cada provedor tem uma lista `models` com `id` (o nome
exato do modelo aceito pela API), preços, contexto e outputs suportados.
Não é necessário tocar no frontend para adicionar um modelo novo.
