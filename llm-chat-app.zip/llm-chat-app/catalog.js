// catalog.js
// Catálogo de provedores e modelos disponíveis.
// Preços em USD por 1.000.000 de tokens (entrada / saída).
// Dados levantados via busca em jun/2026 — confira sempre o site oficial
// do provedor antes de assumir compromissos de custo em produção.

const CATALOG = {
  anthropic: {
    label: "Anthropic",
    color: "#d97757",
    envKey: "ANTHROPIC_API_KEY",
    docsUrl: "https://console.anthropic.com/settings/keys",
    models: [
      {
        id: "claude-haiku-4-5-20251001",
        name: "Claude Haiku 4.5",
        tier: "mais barato",
        input: 1.0,
        output: 5.0,
        context: "200K",
        outputs: ["texto", "código"],
        notes: "Mais rápido e mais barato da Anthropic. Ótimo para fallback."
      },
      {
        id: "claude-sonnet-4-6",
        name: "Claude Sonnet 4.6",
        tier: "equilibrado",
        input: 3.0,
        output: 15.0,
        context: "1M",
        outputs: ["texto", "código"],
        notes: "Bom equilíbrio entre custo e qualidade para uso geral."
      },
      {
        id: "claude-opus-4-7",
        name: "Claude Opus 4.7",
        tier: "mais avançado",
        input: 5.0,
        output: 25.0,
        context: "1M",
        outputs: ["texto", "código"],
        notes: "Modelo mais capaz da Anthropic para raciocínio longo e agentes."
      }
    ]
  },

  openai: {
    label: "OpenAI",
    color: "#74aa9c",
    envKey: "OPENAI_API_KEY",
    docsUrl: "https://platform.openai.com/api-keys",
    models: [
      {
        id: "gpt-5.4-nano",
        name: "GPT-5.4 Nano",
        tier: "mais barato",
        input: 0.20,
        output: 1.25,
        context: "400K",
        outputs: ["texto", "código"],
        notes: "Opção mais barata da OpenAI. Ideal para classificação e tarefas simples."
      },
      {
        id: "gpt-5.4-mini",
        name: "GPT-5.4 Mini",
        tier: "equilibrado",
        input: 0.75,
        output: 4.50,
        context: "400K",
        outputs: ["texto", "código"],
        notes: "Bom custo-benefício para chat de produção."
      },
      {
        id: "gpt-5.5",
        name: "GPT-5.5",
        tier: "mais avançado",
        input: 5.0,
        output: 30.0,
        context: "1M",
        outputs: ["texto", "imagem (input)", "código"],
        notes: "Modelo flagship da OpenAI para raciocínio complexo e coding."
      }
    ]
  },

  gemini: {
    label: "Google Gemini",
    color: "#4796e3",
    envKey: "GEMINI_API_KEY",
    docsUrl: "https://aistudio.google.com/apikey",
    models: [
      {
        id: "gemini-2.5-flash-lite",
        name: "Gemini 2.5 Flash-Lite",
        tier: "grátis (free tier)",
        input: 0,
        output: 0,
        context: "1M",
        outputs: ["texto", "imagem (input)", "áudio (input)"],
        notes: "Free tier sem cartão de crédito via Google AI Studio: ~1.500 requisições/dia. Acima do free tier, vira pago a $0,10/$0,40 por 1M tokens — entre os mais baratos do mercado."
      },
      {
        id: "gemini-3-flash",
        name: "Gemini 3 Flash",
        tier: "grátis (free tier, cota menor)",
        input: 0,
        output: 0,
        context: "1M",
        outputs: ["texto", "imagem (input)", "áudio (input)"],
        notes: "Também coberto pelo free tier do Google AI Studio, com cota diária menor que o Flash-Lite. Acima da cota, $0,50/$3,00 por 1M tokens."
      },
      {
        id: "gemini-3.1-pro",
        name: "Gemini 3.1 Pro",
        tier: "mais avançado (pago)",
        input: 2.0,
        output: 12.0,
        context: "2M",
        outputs: ["texto", "imagem (input)", "áudio (input)", "vídeo (input)"],
        notes: "Flagship do Google, contexto de até 2M tokens. Sem free tier — exige conta paga desde abr/2026."
      }
    ]
  },

  groq: {
    label: "Groq (Llama / open-source)",
    color: "#f55036",
    envKey: "GROQ_API_KEY",
    docsUrl: "https://console.groq.com/keys",
    models: [
      {
        id: "llama-3.1-8b-instant",
        name: "Llama 3.1 8B Instant",
        tier: "grátis (free tier)",
        input: 0,
        output: 0,
        context: "128K",
        outputs: ["texto", "código"],
        notes: "Free tier sem cartão: ~14.400 requisições/dia, 30 req/min. O mais rápido do catálogo (500+ tokens/s em hardware LPU). Acima da cota, $0,05/$0,08 por 1M tokens."
      },
      {
        id: "llama-3.3-70b-versatile",
        name: "Llama 3.3 70B Versatile",
        tier: "grátis (free tier, cota menor)",
        input: 0,
        output: 0,
        context: "128K",
        outputs: ["texto", "código"],
        notes: "Free tier sem cartão: ~1.000 requisições/dia, 30 req/min, 12K tokens/min. Modelo mais robusto do Groq dentro do tier gratuito."
      },
      {
        id: "moonshotai/kimi-k2-instruct",
        name: "Kimi K2 (via Groq)",
        tier: "mais avançado (pago)",
        input: 1.0,
        output: 3.0,
        context: "128K",
        outputs: ["texto", "código"],
        notes: "Modelo mais robusto disponível no Groq, focado em uso agentic. Fora do free tier."
      }
    ]
  },

  cerebras: {
    label: "Cerebras",
    color: "#f5821f",
    envKey: "CEREBRAS_API_KEY",
    docsUrl: "https://cloud.cerebras.ai",
    knownIssue: "O catálogo gratuito da Cerebras é o mais instável entre os provedores deste app: relatos de usuários mostram o número de modelos disponíveis caindo de uma dúzia para apenas 2 (gpt-oss-120b e zai-glm-4.7) de uma vez, sem aviso prévio (caso registrado em 31/05/2026). Se um modelo daqui falhar com 404, confira o catálogo atual em cloud.cerebras.ai antes de assumir que é problema da sua chave.",
    models: [
      {
        id: "llama-4-scout-17b-16e-instruct",
        name: "Llama 4 Scout",
        tier: "grátis (free tier)",
        input: 0,
        output: 0,
        context: "64K (free) / 10M (pago)",
        outputs: ["texto", "código"],
        notes: "Free tier sem cartão: 1.000.000 tokens/dia, 30 req/min — o maior volume diário gratuito entre todos os provedores deste catálogo. Inferência em chip wafer-scale, ~2.600 tokens/s."
      },
      {
        id: "qwen-3-32b",
        name: "Qwen3 32B",
        tier: "grátis (free tier)",
        input: 0,
        output: 0,
        context: "64K (free)",
        outputs: ["texto", "código"],
        notes: "Gratuito dentro do mesmo limite de 1M tokens/dia. Boa opção multilíngue como alternativa ao Llama 4 Scout."
      },
      {
        id: "llama3.1-8b",
        name: "Llama 3.1 8B",
        tier: "grátis (free tier)",
        input: 0,
        output: 0,
        context: "8K (free)",
        outputs: ["texto"],
        notes: "Modelo mais leve do catálogo gratuito da Cerebras — bom como último elo de fallback pela simplicidade do ID."
      }
    ]
  },

  mistral: {
    label: "Mistral AI",
    color: "#fa520f",
    envKey: "MISTRAL_API_KEY",
    docsUrl: "https://console.mistral.ai/api-keys",
    models: [
      {
        id: "mistral-small-latest",
        name: "Mistral Small",
        tier: "grátis (free tier)",
        input: 0,
        output: 0,
        context: "256K",
        outputs: ["texto", "código"],
        notes: "Tier \"Experiment\" gratuito sem cartão (exige verificação de telefone): ~1 requisição/segundo, até 1 bilhão de tokens/mês. Acima disso, $0,10/$0,30 por 1M tokens aprox."
      },
      {
        id: "mistral-medium-latest",
        name: "Mistral Medium",
        tier: "grátis (free tier)",
        input: 0,
        output: 0,
        context: "128K",
        outputs: ["texto", "código"],
        notes: "Coberto pelo mesmo tier Experiment gratuito, com qualidade superior ao Small para tarefas mais elaboradas."
      },
      {
        id: "codestral-latest",
        name: "Codestral",
        tier: "grátis (free tier)",
        input: 0,
        output: 0,
        context: "256K",
        outputs: ["código"],
        notes: "Modelo especializado em código, também dentro do tier gratuito. Bom fallback se sua cadeia for voltada a programação."
      }
    ]
  },

  nvidia: {
    label: "NVIDIA NIM",
    color: "#76b900",
    envKey: "NVIDIA_API_KEY",
    docsUrl: "https://build.nvidia.com",
    knownIssue: "Desde mar/2026, muitas contas \"Personal\" novas recebem chave nvapi- válida mas sem a permissão \"Public API Endpoints\" habilitada — toda chamada de inferência retorna 403 \"Authorization failed\" (às vezes 404), mesmo com a chave correta. Isso é um problema do lado da NVIDIA, sem solução self-service no momento: a seção de permissões nem aparece no menu de Settings para essas contas. Se sua conta tiver esse problema, abra um tópico em forums.developer.nvidia.com (categoria Access/Accounts) pedindo a habilitação manual, e use outro provedor como fallback até lá.",
    models: [
      {
        id: "meta/llama-4-maverick-17b-128e-instruct",
        name: "Llama 4 Maverick",
        tier: "grátis (catálogo NIM)",
        input: 0,
        output: 0,
        context: "1M",
        outputs: ["texto", "imagem (input)", "código"],
        notes: "Gratuito no catálogo hospedado da NVIDIA (limite de ~40 req/min). Sem cartão de crédito."
      },
      {
        id: "deepseek-ai/deepseek-v3.2",
        name: "DeepSeek 3.2",
        tier: "grátis (catálogo NIM)",
        input: 0,
        output: 0,
        context: "128K",
        outputs: ["texto", "código"],
        notes: "Gratuito no catálogo NIM, forte em código e raciocínio."
      },
      {
        id: "meta/llama-3.1-8b-instruct",
        name: "Llama 3.1 8B Instruct",
        tier: "grátis (catálogo NIM)",
        input: 0,
        output: 0,
        context: "128K",
        outputs: ["texto", "código"],
        notes: "Gratuito no catálogo NIM. ID clássico e estável — bom como último elo de fallback, já que o catálogo NIM troca modelos recentes com pouco aviso (ex.: Qwen3 Coder saiu do ar em 11/06/2026)."
      }
    ]
  },

  openrouter: {
    label: "OpenRouter (agregador)",
    color: "#8b5cf6",
    envKey: "OPENROUTER_API_KEY",
    docsUrl: "https://openrouter.ai/keys",
    models: [
      {
        id: "meta-llama/llama-3.1-8b-instruct",
        name: "Llama 3.1 8B Instruct",
        tier: "mais barato",
        input: 0.02,
        output: 0.03,
        context: "128K",
        outputs: ["texto"],
        notes: "A variante \":free\" deste modelo foi descontinuada pelo OpenRouter; este é o slug pago atual, ainda assim muito barato. Confira sempre openrouter.ai/models?order=pricing-low-to-high para opções :free vivas no momento, pois elas mudam com frequência."
      },
      {
        id: "google/gemini-2.5-flash-lite",
        name: "Gemini 2.5 Flash-Lite (via OpenRouter)",
        tier: "mais barato",
        input: 0.10,
        output: 0.40,
        context: "1M",
        outputs: ["texto", "imagem (input)"],
        notes: "Mesmo modelo do Google, roteado pelo OpenRouter com leve markup."
      },
      {
        id: "anthropic/claude-sonnet-4.6",
        name: "Claude Sonnet 4.6 (via OpenRouter)",
        tier: "avançado",
        input: 3.0,
        output: 15.0,
        context: "1M",
        outputs: ["texto", "código"],
        notes: "Acesso a Claude sem precisar de conta direta na Anthropic."
      }
    ]
  }
};

module.exports = { CATALOG };
